#include <iostream>
using namespace std;

int main(){
	int N, sum;
	
	cin >> N;
	cout << "Jumlah semua bilangan ganjil antara 1 s.d " << N << endl; 
	cout << "1";
	for (int i=2; i<=N; i++){
		if (i % 2 !=0){
			sum = sum + i;
			cout << " + " << i;
		}
	}
	cout  << " = " << sum+1;
}
