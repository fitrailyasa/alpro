#include <iostream>
using namespace std;

int main(){
	int a,b,c,max;
	
	cout << "a = ";
	cin >> a;
	cout << "b = ";
	cin >> b;
	cout << "c = ";
	cin >> c;
	
	max = a;
	if (max > b){
		if (b > c){
			cout << a << " " << b << " " << c;
		}
		else {
			cout << a << " " << c << " " << b;
		}
	}
	else if (b > max) {
		if (max > c) {
			cout << b << " " << a << " " << c;
		}
		else {
			cout << b << " " << c << " " << a;
		}
	}
	else if (c > max){
		if (max > b) {
			cout << c << " " << a << " " << b;
		}
		else {
			cout << c << " " << b << " " << a;
		}
	}
}
