#include <iostream>
using namespace std;

bool IsGenap (int x);
int main () {
//kamus
	int i, sum1, sum2;
//algiritma
	sum1 = 0; sum2 = 0;
	for (i = 0; i <= 10; i++){
		if (IsGenap(i)){
			sum1 = sum1 + i;
		} else {
			sum2 = sum2 + i;
		}
	}
	cout << sum1 << endl; //output 30
	cout << sum2 << endl; //output 25
	return 0;
}
bool IsGenap (int x) {
	return (x % 2 == 0);
}

