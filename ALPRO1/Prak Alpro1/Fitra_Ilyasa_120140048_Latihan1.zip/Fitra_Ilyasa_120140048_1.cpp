#include <iostream>
using namespace std;

int main(){
	int suhu,F,R,K;
	string konversi;

	cout << "Masukkan suhu dalam celcius : " << endl;
	cin >> suhu;
	cout << "Masukkan kode konversi : " << endl;
	cin >> konversi;
	
	F = ((9*suhu)/5) + 32;
	R = (4 * suhu)/5;
	K = suhu + 273;
	
	if (konversi == "F"){
		cout << F << " fahrenheit"<< endl;
	}
	else if (konversi == "R"){
		cout << R << " reamur"<< endl;
	}
	else {
		cout << K << " kelvin"<< endl;
	}
	
	return 0;
}
